
"""
Contains virtualized lis for user interface menus code.
"""


class VirtualizedList:
    def __init__(self):
        ...

    def get_list(self):
        ...


def virtualized_lists_generator():
    ...
